#include "nav2_ant_colony_planner/ant_colony_planner.hpp"
#include "nav2_ant_colony_planner/GridMap.h"
#include "nav2_ant_colony_planner/AntColony.h"

#include "pluginlib/class_list_macros.hpp"

PLUGINLIB_EXPORT_CLASS(nav2_ant_colony_planner::AntColonyPlanner, nav2_core::GlobalPlanner)

namespace nav2_ant_colony_planner {

void AntColonyPlanner::configure(
  const rclcpp_lifecycle::LifecycleNode::WeakPtr & parent,
  std::string /*name*/,
  std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros)
{
  node_ = parent;
  costmap_ros_ = costmap_ros;
  RCLCPP_INFO(logger_, "Ant Colony Planner configured");
}

void AntColonyPlanner::cleanup()
{
  RCLCPP_INFO(logger_, "Ant Colony Planner cleaned up");
}

void AntColonyPlanner::activate()
{
  RCLCPP_INFO(logger_, "Ant Colony Planner activated");
}

void AntColonyPlanner::deactivate()
{
  RCLCPP_INFO(logger_, "Ant Colony Planner deactivated");
}

nav_msgs::msg::Path AntColonyPlanner::createPlan(
  const geometry_msgs::msg::PoseStamped & start,
  const geometry_msgs::msg::PoseStamped & goal)
{
  nav_msgs::msg::Path path;
  path.header.frame_id = start.header.frame_id;
  path.header.stamp = rclcpp::Clock().now();

  // 从Costmap构建GridMap
  auto costmap = costmap_ros_->getCostmap();
  GridMap grid_map(costmap->getSizeInCellsX(), costmap->getSizeInCellsY());

  for (unsigned int y = 0; y < costmap->getSizeInCellsY(); y++) {
    for (unsigned int x = 0; x < costmap->getSizeInCellsX(); x++) {
      if (costmap->getCost(x, y) >= nav2_costmap_2d::LETHAL_OBSTACLE) {
        grid_map.markObstacle(x, y);
      }
    }
  }

  std::pair<int, int> start_coord(
    static_cast<int>(start.pose.position.x), 
    static_cast<int>(start.pose.position.y));

  std::pair<int, int> goal_coord(
    static_cast<int>(goal.pose.position.x), 
    static_cast<int>(goal.pose.position.y));

  // 使用AntColony算法计算路径
  AntColony ant_colony(grid_map, 100, 20, start_coord, goal_coord);
  ant_colony.run();

  const auto& best_path = ant_colony.bestPath;

  if (best_path.empty()) {
    RCLCPP_WARN(logger_, "No valid path found by Ant Colony");
    return path; // 返回空路径
  }

  for (const auto & cell : best_path) {
    geometry_msgs::msg::PoseStamped pose;
    pose.pose.position.x = static_cast<double>(cell.first);
    pose.pose.position.y = static_cast<double>(cell.second);
    pose.pose.position.z = 0.0;
    pose.pose.orientation.w = 1.0;
    path.poses.push_back(pose);
  }

  RCLCPP_INFO(logger_, "Ant Colony Planner found path with %zu points.", path.poses.size());
  
  return path;
}

}  // namespace nav2_ant_colony_planner

