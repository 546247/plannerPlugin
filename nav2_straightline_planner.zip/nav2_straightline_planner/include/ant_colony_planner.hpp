// ant_colony_planner.hpp
#ifndef NAV2_ANT_COLONY_PLANNER__ANT_COLONY_PLANNER_HPP_
#define NAV2_ANT_COLONY_PLANNER__ANT_COLONY_PLANNER_HPP_

#include <string>
#include <memory>
#include <vector>
#include "rclcpp/rclcpp.hpp"
#include "nav2_core/global_planner.hpp"
#include "nav_msgs/msg/path.hpp"
#include "nav2_util/robot_utils.hpp"
#include "nav2_util/lifecycle_node.hpp"
#include "nav2_costmap_2d/costmap_2d_ros.hpp"

namespace nav2_ant_colony_planner
{

class AntColonyPlanner : public nav2_core::GlobalPlanner
{
public:
  AntColonyPlanner() = default;
  ~AntColonyPlanner() override = default;

  // 插件配置、激活、清理等生命周期方法
  void configure(
    const rclcpp_lifecycle::LifecycleNode::WeakPtr & parent,
    std::string name, std::shared_ptr<tf2_ros::Buffer> tf,
    std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros) override;

  void cleanup() override;
  void activate() override;
  void deactivate() override;

  // 主要路径规划方法
  nav_msgs::msg::Path createPlan(
    const geometry_msgs::msg::PoseStamped & start,
    const geometry_msgs::msg::PoseStamped & goal) override;

private:
  // 将Costmap2D转换为GridMap格式供蚁群算法使用
  std::vector<std::vector<bool>> convertCostmapToGrid();

  // ROS2相关成员
  rclcpp_lifecycle::LifecycleNode::WeakPtr node_;
  std::shared_ptr<tf2_ros::Buffer> tf_;
  std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros_;
  std::shared_ptr<nav2_costmap_2d::Costmap2D> costmap_;
  std::string global_frame_;
  std::string name_;

  // 蚁群算法参数
  int ant_count_;
  int max_iterations_;
  double alpha_;
  double beta_;
  double evaporation_rate_;
  double Q_;
};

}  // namespace nav2_ant_colony_planner

#endif  // NAV2_ANT_COLONY_PLANNER__ANT_COLONY_PLANNER_HPP_
