// ant_colony_planner.cpp
#include "nav2_ant_colony_planner/ant_colony_planner.hpp"
#include "nav2_util/node_utils.hpp"
#include "nav2_costmap_2d/cost_values.hpp"

namespace nav2_ant_colony_planner
{

void AntColonyPlanner::configure(
  const rclcpp_lifecycle::LifecycleNode::WeakPtr & parent,
  std::string name, std::shared_ptr<tf2_ros::Buffer> tf,
  std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros)
{
  node_ = parent.lock();
  name_ = name;
  tf_ = tf;
  costmap_ros_ = costmap_ros;
  costmap_ = costmap_ros->getCostmap();
  global_frame_ = costmap_ros->getGlobalFrameID();

  // 参数声明和获取
  nav2_util::declare_parameter_if_not_declared(
    node_, name_ + ".ant_count", rclcpp::ParameterValue(50));
  nav2_util::declare_parameter_if_not_declared(
    node_, name_ + ".max_iterations", rclcpp::ParameterValue(20));
  nav2_util::declare_parameter_if_not_declared(
    node_, name_ + ".alpha", rclcpp::ParameterValue(1.0));
  nav2_util::declare_parameter_if_not_declared(
    node_, name_ + ".beta", rclcpp::ParameterValue(2.0));
  nav2_util::declare_parameter_if_not_declared(
    node_, name_ + ".evaporation_rate", rclcpp::ParameterValue(0.5));
  nav2_util::declare_parameter_if_not_declared(
    node_, name_ + ".Q", rclcpp::ParameterValue(1.0));

  node_->get_parameter(name_ + ".ant_count", ant_count_);
  node_->get_parameter(name_ + ".max_iterations", max_iterations_);
  node_->get_parameter(name_ + ".alpha", alpha_);
  node_->get_parameter(name_ + ".beta", beta_);
  node_->get_parameter(name_ + ".evaporation_rate", evaporation_rate_);
  node_->get_parameter(name_ + ".Q", Q_);
}

void AntColonyPlanner::cleanup()
{
  RCLCPP_INFO(
    node_->get_logger(), "Cleaning up plugin %s of type AntColonyPlanner",
    name_.c_str());
}

void AntColonyPlanner::activate()
{
  RCLCPP_INFO(
    node_->get_logger(), "Activating plugin %s of type AntColonyPlanner",
    name_.c_str());
}

void AntColonyPlanner::deactivate()
{
  RCLCPP_INFO(
    node_->get_logger(), "Deactivating plugin %s of type AntColonyPlanner",
    name_.c_str());
}

std::vector<std::vector<bool>> AntColonyPlanner::convertCostmapToGrid()
{
  unsigned int size_x = costmap_->getSizeInCellsX();
  unsigned int size_y = costmap_->getSizeInCellsY();
  
  std::vector<std::vector<bool>> grid(size_x, std::vector<bool>(size_y, false));
  
  for (unsigned int y = 0; y < size_y; y++) {
    for (unsigned int x = 0; x < size_x; x++) {
      // 将障碍物或未知区域标记为true
      unsigned char cost = costmap_->getCost(x, y);
      grid[x][y] = (cost == nav2_costmap_2d::LETHAL_OBSTACLE || 
                   cost == nav2_costmap_2d::NO_INFORMATION);
    }
  }
  
  return grid;
}

nav_msgs::msg::Path AntColonyPlanner::createPlan(
  const geometry_msgs::msg::PoseStamped & start,
  const geometry_msgs::msg::PoseStamped & goal)
{
  nav_msgs::msg::Path global_path;
  global_path.header.stamp = node_->now();
  global_path.header.frame_id = global_frame_;

  // 检查坐标系
  if (start.header.frame_id != global_frame_) {
    RCLCPP_ERROR(
      node_->get_logger(), "Planner will only accept start position from %s frame",
      global_frame_.c_str());
    return global_path;
  }

  if (goal.header.frame_id != global_frame_) {
    RCLCPP_ERROR(
      node_->get_logger(), "Planner will only accept goal position from %s frame",
      global_frame_.c_str());
    return global_path;
  }

  // 将起点和终点转换为地图坐标
  unsigned int start_x, start_y, goal_x, goal_y;
  if (!costmap_->worldToMap(start.pose.position.x, start.pose.position.y, start_x, start_y)) {
    RCLCPP_WARN(
      node_->get_logger(), "Cannot convert start position to map coordinates");
    return global_path;
  }

  if (!costmap_->worldToMap(goal.pose.position.x, goal.pose.position.y, goal_x, goal_y)) {
    RCLCPP_WARN(
      node_->get_logger(), "Cannot convert goal position to map coordinates");
    return global_path;
  }

  // 创建GridMap并运行蚁群算法
  GridMap grid_map(costmap_->getSizeInCellsX(), costmap_->getSizeInCellsY());
  auto grid = convertCostmapToGrid();
  
  // 标记障碍物
  for (unsigned int y = 0; y < costmap_->getSizeInCellsY(); y++) {
    for (unsigned int x = 0; x < costmap_->getSizeInCellsX(); x++) {
      if (grid[x][y]) {
        grid_map.markObstacle(x, y);
      }
    }
  }

  // 运行蚁群算法
  AntColony ant_colony(
    grid_map, 
    ant_count_, 
    max_iterations_, 
    {static_cast<int>(start_x), static_cast<int>(start_y)}, 
    {static_cast<int>(goal_x), static_cast<int>(goal_y)}
  );
  
  ant_colony.alpha = alpha_;
  ant_colony.beta = beta_;
  ant_colony.evaporationRate = evaporation_rate_;
  ant_colony.Q = Q_;
  
  ant_colony.run();
  auto best_path = ant_colony.getBestPath();

  // 将路径转换为ROS Path消息
  for (const auto& point : best_path) {
    double wx, wy;
    costmap_->mapToWorld(point.first, point.second, wx, wy);
    
    geometry_msgs::msg::PoseStamped pose;
    pose.pose.position.x = wx;
    pose.pose.position.y = wy;
    pose.pose.position.z = 0.0;
    pose.pose.orientation = nav2_util::geometry_utils::orientationAroundZAxis(
      atan2(point.second - start_y, point.first - start_x));
    pose.header.stamp = node_->now();
    pose.header.frame_id = global_frame_;
    global_path.poses.push_back(pose);
  }

  return global_path;
}

}  // namespace nav2_ant_colony_planner

#include "pluginlib/class_list_macros.hpp"
PLUGINLIB_EXPORT_CLASS(nav2_ant_colony_planner::AntColonyPlanner, nav2_core::GlobalPlanner)
